const https = require("https");
const url = "https://html.duckduckgo.com/html/?q=" + encodeURIComponent("man-installs-heating-system-house-checks-pipes-with-wrench_219637114");

https.get(url, {
  headers: {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
  }
}, (res) => {
  let data = "";
  res.on("data", c => data += c);
  res.on("end", () => {
    console.log("DDG results length:", data.length);
    const match = data.match(/img\.freepik\.com[^"'\s<>]+/ig) || data.match(/https:\/\/[A-Za-z0-9\-\.\/_-]+\.jpg/ig);
    console.log("DDG match:", match ? match.slice(0, 5) : "not found");
  });
});
