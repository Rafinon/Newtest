import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Droplets, Phone, Menu, X, MapPin, Clock, ClipboardList, Shield, Award, 
  CheckCircle, User, Wrench, Star, HardHat, CalendarCheck, ArrowRight, 
  Camera, Expand, Droplet, Route, History, DollarSign, Medal, ChevronRight, 
  Mail, Building, Calculator, Check, ArrowLeftRight, ChevronDown, ChevronUp
} from 'lucide-react';

export default function App() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);

  // Calculator State
  const [calcService, setCalcService] = useState("General Plumbing Repair");
  const [calcLength, setCalcLength] = useState(50);
  const [calcDiameter, setCalcDiameter] = useState("4");

  const calculateCost = () => {
    let basePrice = 0;
    if (calcService === "General Plumbing Repair") basePrice = 120;
    else if (calcService === "Drain Cleaning") basePrice = 15;
    else if (calcService === "Main Line Replacement") basePrice = 140;
    else if (calcService === "Leak Detection") basePrice = 5;

    let multiplier = 1;
    if (calcDiameter === "6") multiplier = 1.5;
    else if (calcDiameter === "8") multiplier = 2;

    const total = basePrice * calcLength * multiplier;
    
    // Add base fee for smaller jobs
    const finalTotal = (calcService === "Leak Detection" || calcService === "Drain Cleaning") ? total + 250 : total;

    const min = Math.floor(finalTotal * 0.9);
    const max = Math.ceil(finalTotal * 1.1);

    return `$${min.toLocaleString()} – $${max.toLocaleString()}`;
  };

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const services = [
    { title: "Smart Leak Detection", desc: "Protect your home with smart water shutoff and 24/7 leak protection systems.", icon: <Droplet className="w-6 h-6" />, image: "https://plus.unsplash.com/premium_photo-1664301972519-506636f0245d?q=80&w=2696&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" },
    { title: "Main Sewer Line Upgrades", desc: "Expert main sewer line upgrades and replacements to keep your system flowing smoothly.", icon: <Route className="w-6 h-6" />, image: "https://lh3.googleusercontent.com/d/1vvKlS5mmDxTFoXGuH3JqLUy2_RKwmNy1" },
    { title: "Trenchless Pipe Lining", desc: "Restore cracked or corroded pipes from the inside without digging up your yard.", icon: <Wrench className="w-6 h-6" />, image: "https://images.pexels.com/photos/9658236/pexels-photo-9658236.jpeg?auto=compress&cs=tinysrgb&w=600" },
    { title: "CCTV Camera Inspection", desc: "See exactly what's wrong with HD sewer cameras before spending a dime on repairs.", icon: <Camera className="w-6 h-6" />, image: "https://lh3.googleusercontent.com/d/1fUSdi6i85KlAiMSXNaaJ6OuzS04OoIg0" },
    { title: "Hydro Jetting", desc: "Blast away years of grease, roots, debris, and scale with high-pressure water.", icon: <Droplets className="w-6 h-6" />, image: "https://lh3.googleusercontent.com/d/1zeVSCElfNvqdfTVuO0B-BsaxUM5JeCQg" },
    { title: "General Plumbing Services", desc: "Fast & friendly service for any plumbing need: leaks, clogs, drains, and more.", icon: <Wrench className="w-6 h-6" />, image: "https://lh3.googleusercontent.com/d/1RtY-elZouGrwkOMSmBq1LJRer14Kx5Nz" }
  ];

  return (
    <div className="min-h-screen font-sans text-gray-900">
      {/* Header */}
      <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-secondary-dark/95 backdrop-blur-md shadow-lg py-3' : 'bg-transparent py-5'}`}>
        <div className="container mx-auto px-4 md:px-6 flex items-center justify-between">
          <a href="#" className="flex items-center gap-3 text-white group">
            <img src="/1000165154-removebg-preview.png" alt="Premium Pros Plumbing Logo" className="h-12 w-auto group-hover:scale-105 transition-transform" />
            <div className="flex flex-col leading-tight">
              <span className="font-heading font-extrabold text-lg tracking-tight whitespace-nowrap">Premium Pros Plumbing</span>
            </div>
          </a>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            <a href="#services" className="text-white/90 hover:text-primary font-semibold text-sm transition-colors">Services</a>
            <a href="#why-us" className="text-white/90 hover:text-primary font-semibold text-sm transition-colors">Why Us</a>
            <a href="#reviews" className="text-white/90 hover:text-primary font-semibold text-sm transition-colors">Reviews</a>
            <a href="tel:+13235978330" className="text-primary font-bold text-sm flex items-center gap-2 hover:text-primary-light transition-colors">
              <Phone className="w-4 h-4" /> (323) 597-8330
            </a>
            <a href="#quote" className="btn-primary px-6 py-2.5 rounded-full font-bold text-sm flex items-center gap-2">
              Get Free Estimate
            </a>
          </nav>

          {/* Mobile Menu Toggle */}
          <button className="md:hidden text-white p-2" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Nav */}
        {isMobileMenuOpen && (
          <div className="md:hidden absolute top-full left-0 right-0 bg-secondary-dark border-t border-white/10 shadow-xl">
            <div className="flex flex-col p-4 space-y-4">
              <a href="#services" onClick={() => setIsMobileMenuOpen(false)} className="text-white font-semibold p-2 hover:bg-white/5 rounded">Services</a>
              <a href="#why-us" onClick={() => setIsMobileMenuOpen(false)} className="text-white font-semibold p-2 hover:bg-white/5 rounded">Why Us</a>
              <a href="#reviews" onClick={() => setIsMobileMenuOpen(false)} className="text-white font-semibold p-2 hover:bg-white/5 rounded">Reviews</a>
              <a href="tel:+13235978330" className="text-primary font-bold p-2 flex items-center gap-2">
                <Phone className="w-5 h-5" /> (323) 597-8330
              </a>
              <a href="#quote" onClick={() => setIsMobileMenuOpen(false)} className="btn-primary text-center py-3 rounded-xl font-bold">
                Get Free Estimate
              </a>
            </div>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section className="relative min-h-[100svh] flex items-center pt-24 pb-16 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src="https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=1600&q=80" alt="Plumbing repair" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          <div className="absolute inset-0 hero-overlay"></div>
        </div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10 flex flex-col lg:flex-row items-center gap-12">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="flex-1 text-center lg:text-left pt-10 lg:pt-0"
          >
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="inline-flex items-center gap-2 bg-white/10 text-white shadow-lg border border-white/20 px-5 py-2 rounded-full text-sm font-bold mb-6 backdrop-blur-sm"
            >
              <MapPin className="w-5 h-5 text-primary" /> Serving LA, OC, and IE Area
            </motion.div>
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.5 }}
              className="text-4xl md:text-5xl lg:text-6xl font-heading font-black text-white leading-tight mb-6"
            >
              Premium <span className="text-primary">Plumbing Services</span> You Can Trust
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.5 }}
              className="text-lg md:text-xl text-white/80 mb-8 max-w-2xl mx-auto lg:mx-0 font-medium"
            >
              We can match your price, giving you the best price for you! • FREE ESTIMATES • Hablamos Español!
            </motion.p>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.5 }}
              className="inline-flex items-center gap-3 bg-primary/20 border border-primary/40 text-blue-100 px-5 py-3 rounded-xl font-semibold mb-8 backdrop-blur-sm text-left"
            >
              <DollarSign className="w-6 h-6 flex-shrink-0 text-primary" />
              <span><strong>Price Match Guarantee</strong> — We'll beat any written estimate!</span>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.5 }}
              className="flex flex-col sm:flex-row items-center gap-4 justify-center lg:justify-start mb-10"
            >
              <motion.a whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} href="#quote" className="btn-primary w-full sm:w-auto px-8 py-4 rounded-full font-bold text-lg flex items-center justify-center gap-2">
                <ClipboardList className="w-5 h-5" /> Get Free Estimate
              </motion.a>
              <motion.a whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} href="tel:+13235978330" className="btn-call w-full sm:w-auto px-8 py-4 rounded-full font-bold text-lg flex items-center justify-center gap-2">
                <Phone className="w-5 h-5" /> (323) 597-8330
              </motion.a>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8, duration: 0.5 }}
              className="flex flex-wrap justify-center lg:justify-start gap-4"
            >
              <div className="flex items-center gap-2 bg-white/10 border border-white/20 backdrop-blur-md px-4 py-2 rounded-full text-white text-sm font-semibold">
                <div className="flex text-primary"><Star className="w-4 h-4 fill-current"/><Star className="w-4 h-4 fill-current"/><Star className="w-4 h-4 fill-current"/><Star className="w-4 h-4 fill-current"/><Star className="w-4 h-4 fill-current"/></div>
                Top Rated Service
              </div>
              <div className="flex items-center gap-2 bg-white/10 border border-white/20 backdrop-blur-md px-4 py-2 rounded-full text-white text-sm font-semibold">
                <Medal className="w-4 h-4 text-primary" /> Price Matching
              </div>
              <div className="flex items-center gap-2 bg-white/10 border border-white/20 backdrop-blur-md px-4 py-2 rounded-full text-white text-sm font-semibold">
                <MapPin className="w-4 h-4 text-primary" /> LA, OC & IE
              </div>
            </motion.div>
          </motion.div>

          {/* Quote Form */}
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3, ease: "easeOut" }}
            className="w-full max-w-md" id="quote"
          >
            <div className="bg-white rounded-2xl p-6 md:p-8 shadow-2xl border-t-4 border-primary relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-bl-full -z-10"></div>
              <div className="text-center mb-6">
                <h2 className="font-heading text-2xl font-extrabold text-secondary mb-2">Get Your FREE Estimate</h2>
                <p className="text-gray-500 text-sm">No obligation • Same-day response</p>
              </div>
              <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                <div>
                  <label className="flex items-center gap-2 text-sm font-bold text-gray-700 mb-1">
                    <User className="w-4 h-4 text-primary" /> Full Name *
                  </label>
                  <input type="text" placeholder="John Smith" className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-primary focus:ring-4 focus:ring-primary/10 outline-none transition-all" required />
                </div>
                <div>
                  <label className="flex items-center gap-2 text-sm font-bold text-gray-700 mb-1">
                    <Phone className="w-4 h-4 text-primary" /> Phone Number *
                  </label>
                  <input type="tel" placeholder="(555) 123-4567" className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-primary focus:ring-4 focus:ring-primary/10 outline-none transition-all" required />
                </div>
                <div>
                  <label className="flex items-center gap-2 text-sm font-bold text-gray-700 mb-1">
                    <MapPin className="w-4 h-4 text-primary" /> Property Address *
                  </label>
                  <input type="text" placeholder="123 Main St, Los Angeles, CA" className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-primary focus:ring-4 focus:ring-primary/10 outline-none transition-all" required />
                </div>
                <div>
                  <label className="flex items-center gap-2 text-sm font-bold text-gray-700 mb-1">
                    <Wrench className="w-4 h-4 text-primary" /> Service Needed *
                  </label>
                  <select className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-primary focus:ring-4 focus:ring-primary/10 outline-none transition-all bg-white" required>
                    <option value="">-- Select a Service --</option>
                    <option>General Plumbing</option>
                    <option>Drain Cleaning</option>
                    <option>Leak Detection</option>
                    <option>Water Heaters</option>
                    <option>Emergency Service</option>
                  </select>
                </div>
                <motion.button 
                  whileHover={{ scale: 1.02 }} 
                  whileTap={{ scale: 0.98 }} 
                  type="submit" 
                  className="btn-primary w-full py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 mt-2"
                >
                  Send Request
                </motion.button>
                <p className="text-xs text-center text-gray-500 flex items-center justify-center gap-1 mt-4">
                  <Shield className="w-3 h-3" /> 100% Free. No obligation. Your info is private.
                </p>
              </form>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Social Proof Bar */}
      <div className="bg-secondary py-6">
        <div className="container mx-auto px-4 flex flex-wrap justify-center gap-x-8 gap-y-4">
          <div className="flex items-center gap-2 text-white font-semibold text-sm md:text-base">
            <Star className="w-5 h-5 text-primary fill-current" /> 127+ 5-Star Reviews
          </div>
          <div className="flex items-center gap-2 text-white font-semibold text-sm md:text-base">
            <HardHat className="w-5 h-5 text-primary" /> 2,500+ Jobs Completed
          </div>
          <div className="flex items-center gap-2 text-white font-semibold text-sm md:text-base">
            <CalendarCheck className="w-5 h-5 text-primary" /> Top Rated Plumbers
          </div>
          <div className="flex items-center gap-2 text-white font-semibold text-sm md:text-base">
            <Shield className="w-5 h-5 text-primary" /> Licensed &amp; Insured (CA)
          </div>
        </div>
      </div>

      {/* Services Section */}
      <section id="services" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto mb-16"
          >
            <span className="section-label">What We Do</span>
            <h2 className="text-3xl md:text-4xl font-heading font-extrabold text-secondary mb-4">Our Premium Plumbing Services</h2>
            <p className="text-gray-600 text-lg">Industry-leading plumbing solutions that save your money and your time.</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, idx) => (
              <motion.div 
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                key={idx} 
                className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow border border-gray-100 group"
              >
                <div className="h-48 bg-gray-100 relative overflow-hidden flex items-center justify-center">
                  <img src={service.image} alt={service.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" referrerPolicy="no-referrer" />
                  <div className="absolute bottom-4 right-4 w-12 h-12 bg-gradient-to-br from-primary to-primary-dark rounded-full flex items-center justify-center text-white shadow-lg">
                    {service.icon}
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="font-heading text-xl font-bold text-secondary mb-3">{service.title}</h3>
                  <p className="text-gray-600 mb-6 line-clamp-3">{service.desc}</p>
                  <a href="#quote" className="inline-flex items-center gap-2 text-primary font-bold hover:text-primary-dark transition-colors">
                    Get a Quote <ArrowRight className="w-4 h-4" />
                  </a>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section id="why-us" className="py-20 bg-white overflow-hidden">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6 }}
              className="flex-1 relative"
            >
              <img src="https://images.unsplash.com/photo-1613839397604-65fffe7fc3d4?q=80&w=2676&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Plumber" className="rounded-2xl shadow-2xl" referrerPolicy="no-referrer" />
              <div className="absolute -bottom-8 -left-8 bg-gradient-to-br from-primary to-primary-dark p-6 rounded-2xl shadow-xl text-center hidden md:block">
                <div className="font-heading text-5xl font-black text-white leading-none mb-1">Top</div>
                <div className="text-white/90 font-bold text-sm">Rated Premium Plumbers</div>
              </div>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="flex-1"
            >
              <span className="section-label">Why Choose Us</span>
              <h2 className="text-3xl md:text-4xl font-heading font-extrabold text-secondary mb-6 leading-tight">Southern California's Premium Plumbing Experts</h2>
              <p className="text-gray-600 text-lg mb-8">When your plumbing fails, you need someone you can trust — fast. We've been protecting homes across LA, OC, and IE with proven, reliable service.</p>
              
              <div className="space-y-6 mb-10">
                {[
                  { icon: <Shield />, title: "Bilingual / Hablamos Español", desc: "We proudly serve our community with clear communication." },
                  { icon: <History />, title: "Fast & Friendly Service", desc: "We respond quickly and treat your home with respect." },
                  { icon: <DollarSign />, title: "Price Match Guarantee", desc: "Got a written estimate? We'll match or beat it!" },
                  { icon: <Medal />, title: "Premium Quality Guarantee", desc: "We stand behind every repair with our quality guarantee." }
                ].map((item, idx) => (
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: 0.3 + (idx * 0.1) }}
                    key={idx} 
                    className="flex gap-4"
                  >
                    <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary flex-shrink-0">
                      {item.icon}
                    </div>
                    <div>
                      <h4 className="font-bold text-lg text-secondary mb-1">{item.title}</h4>
                      <p className="text-gray-600 text-sm">{item.desc}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
              <motion.a whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} href="#quote" className="btn-primary px-8 py-4 rounded-full font-bold text-lg inline-flex items-center gap-2">
                Get My Free Estimate <ArrowRight className="w-5 h-5" />
              </motion.a>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto mb-16"
          >
            <span className="section-label">How It Works</span>
            <h2 className="text-3xl md:text-4xl font-heading font-extrabold text-secondary mb-4">Our Simple 3-Step Process</h2>
            <p className="text-gray-600 text-lg">From your first call to job completion — we make plumbing repairs fast and stress-free.</p>
          </motion.div>

          <div className="flex flex-col md:flex-row items-center justify-center gap-8 relative">
            <div className="hidden md:block absolute top-1/2 left-0 w-full h-1 bg-gray-200 -translate-y-1/2 z-0"></div>
            
            {[
              { num: "01", icon: <ClipboardList className="w-8 h-8"/>, title: "Request Free Quote", desc: "Call us or fill out our quick form. Same-day appointments available." },
              { num: "02", icon: <Camera className="w-8 h-8"/>, title: "Expert Diagnosis", desc: "We diagnose the problem quickly and provide a transparent written quote." },
              { num: "03", icon: <CheckCircle className="w-8 h-8"/>, title: "Premium Service", desc: "We complete the repair properly the first time, leaving your home spotless." }
            ].map((step, idx) => (
              <motion.div 
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.5, delay: idx * 0.2 }}
                key={idx} 
                className="bg-white border-2 border-gray-100 rounded-2xl p-8 text-center relative z-10 w-full md:w-1/3 shadow-lg hover:border-primary transition-colors group"
              >
                <div className="absolute -top-6 left-1/2 -translate-x-1/2 font-heading text-6xl font-black text-gray-100 group-hover:text-primary/10 transition-colors">{step.num}</div>
                <div className="w-20 h-20 mx-auto bg-gradient-to-br from-primary to-primary-dark rounded-2xl flex items-center justify-center text-white shadow-lg mb-6 relative z-10">
                  {step.icon}
                </div>
                <h3 className="font-heading font-bold text-xl text-secondary mb-3 relative z-10">{step.title}</h3>
                <p className="text-gray-600 relative z-10">{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Before / After Showcase */}
      <section className="py-20 bg-white overflow-hidden">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto mb-16"
          >
            <span className="section-label">Real Results</span>
            <h2 className="text-3xl md:text-4xl font-heading font-extrabold text-secondary mb-4">Plumbing Transformations</h2>
            <p className="text-gray-600 text-lg">See the difference our premium service makes — clean, reliable, and done right.</p>
          </motion.div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { title: "Sewer Line Repair", location: "Burbank, CA", desc: "Main sewer line was completely blocked by tree roots. Unclogged and repaired within 4 hours.", before: "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=500&q=80", after: "https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=500&q=80" },
              { title: "Old Pipe Upgrades", location: "Pasadena, CA", desc: "80-year-old cast-iron pipes replaced with modern piping. Water pressure restored and leaks fixed.", before: "https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=500&q=80", after: "https://images.unsplash.com/photo-1541888087425-ce81df8219fc?w=500&q=80" },
              { title: "Drain Cleaning", location: "Westminster, CA", desc: "Restaurant main drain blocked with grease. Cleaned and restored to 100% flow quickly.", before: "https://images.unsplash.com/photo-1607400201889-565b1ee75f8e?w=500&q=80", after: "https://images.unsplash.com/photo-1545165375-1b744b9ed444?w=500&q=80" }
            ].map((item, idx) => (
              <motion.div 
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.5, delay: idx * 0.2 }}
                key={idx} 
                className="bg-gray-50 rounded-2xl overflow-hidden shadow-lg border border-gray-100"
              >
                <div className="flex h-48 relative">
                  <div className="flex-1 relative overflow-hidden">
                    <img src={item.before} alt="Before" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    <span className="absolute bottom-2 left-2 bg-red-500 text-white text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-wider">Before</span>
                  </div>
                  <div className="w-10 bg-secondary flex items-center justify-center text-white z-10 shadow-xl">
                    <ArrowLeftRight className="w-5 h-5" />
                  </div>
                  <div className="flex-1 relative overflow-hidden">
                    <img src={item.after} alt="After" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    <span className="absolute bottom-2 left-2 bg-green-500 text-white text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-wider">After</span>
                  </div>
                </div>
                <div className="p-6">
                  <h4 className="font-bold text-secondary mb-1">{item.title}</h4>
                  <p className="text-primary text-xs font-bold mb-3">{item.location}</p>
                  <p className="text-gray-600 text-sm">{item.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Cost Calculator */}
      <section className="py-20 bg-gray-50 overflow-hidden">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto mb-12"
          >
            <span className="section-label">Estimate Tool</span>
            <h2 className="text-3xl md:text-4xl font-heading font-extrabold text-secondary mb-4">Plumbing Cost Estimator</h2>
            <p className="text-gray-600 text-lg">Get a ballpark estimate in seconds. For an exact quote, call us or fill out the form above.</p>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.6 }}
            className="max-w-4xl mx-auto bg-white rounded-2xl shadow-xl border border-gray-200 p-8 md:p-12 flex flex-col md:flex-row gap-12 items-center"
          >
            <div className="flex-1 w-full space-y-6">
              <div>
                <label className="block font-bold text-secondary mb-2">Service Type</label>
                <select 
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-primary outline-none"
                  value={calcService}
                  onChange={(e) => setCalcService(e.target.value)}
                >
                  <option value="General Plumbing Repair">General Plumbing Repair</option>
                  <option value="Drain Cleaning">Drain Cleaning</option>
                  <option value="Main Line Replacement">Main Line Replacement</option>
                  <option value="Leak Detection">Leak Detection</option>
                </select>
              </div>
              <div>
                <label className="block font-bold text-secondary mb-2">Pipe Length (linear feet): {calcLength} ft</label>
                <input 
                  type="range" 
                  min="10" 
                  max="200" 
                  value={calcLength} 
                  onChange={(e) => setCalcLength(parseInt(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-primary" 
                />
              </div>
              <div>
                <label className="block font-bold text-secondary mb-2">Pipe Diameter</label>
                <select 
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-primary outline-none"
                  value={calcDiameter}
                  onChange={(e) => setCalcDiameter(e.target.value)}
                >
                  <option value="4">4" (Standard residential)</option>
                  <option value="6">6" (Main sewer line)</option>
                  <option value="8">8" (Commercial)</option>
                </select>
              </div>
            </div>
            <div className="flex-1 w-full bg-gradient-to-br from-secondary to-secondary-dark rounded-2xl p-8 text-center text-white shadow-lg">
              <div className="text-sm font-bold uppercase tracking-wider text-white/70 mb-2">Estimated Range</div>
              <div className="font-heading text-4xl md:text-5xl font-black text-primary mb-4">{calculateCost()}</div>
              <p className="text-sm text-white/60 mb-8">* Estimates are for reference only. Actual price may vary based on site conditions, access, and material.</p>
              <motion.a whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} href="#quote" className="btn-primary w-full py-3 rounded-xl font-bold flex items-center justify-center gap-2">
                Get Exact Free Quote <ArrowRight className="w-4 h-4" />
              </motion.a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="reviews" className="py-20 bg-secondary-dark text-white overflow-hidden">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto mb-16"
          >
            <span className="section-label">Customer Reviews</span>
            <h2 className="text-3xl md:text-4xl font-heading font-extrabold mb-4">What Our Customers Are Saying</h2>
            <div className="flex flex-col items-center gap-2 mt-4">
              <div className="flex text-primary text-xl"><Star className="fill-current"/><Star className="fill-current"/><Star className="fill-current"/><Star className="fill-current"/><Star className="fill-current"/></div>
              <p><strong>4.9 out of 5</strong> based on <strong>200+ Google Reviews</strong></p>
            </div>
          </motion.div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { name: "Mike R.", loc: "Burbank, CA", text: "Premium Pros Plumbing is amazing! They fixed my leak quickly and their price was unbeatable. I highly recommend them to anyone in the area." },
              { name: "Sandra L.", loc: "Pasadena, CA", text: "Called at 7am with a plumbing emergency and they had a crew out by 9am. They fixed the issue right away and were incredibly professional." },
              { name: "David & Tracy K.", loc: "Los Angeles, CA", text: "Best investment we've made in our home. Their service is top-notch, and the price match guarantee saved us hundreds of dollars." }
            ].map((review, idx) => (
              <motion.div 
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.5, delay: idx * 0.2 }}
                key={idx} 
                className="bg-white/5 border border-white/10 rounded-2xl p-8 backdrop-blur-sm hover:bg-white/10 transition-colors"
              >
                <div className="flex text-primary mb-4"><Star className="w-4 h-4 fill-current"/><Star className="w-4 h-4 fill-current"/><Star className="w-4 h-4 fill-current"/><Star className="w-4 h-4 fill-current"/><Star className="w-4 h-4 fill-current"/></div>
                <p className="italic text-white/80 mb-6 line-clamp-4">"{review.text}"</p>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-primary-dark flex items-center justify-center font-bold text-lg">
                    {review.name.charAt(0)}
                  </div>
                  <div>
                    <div className="font-bold">{review.name}</div>
                    <div className="text-xs text-white/50">{review.loc}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Local SEO & Service Areas */}
      <section className="py-20 bg-white border-b border-gray-100 overflow-hidden">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-50px" }}
          transition={{ duration: 0.6 }}
          className="container mx-auto px-4 md:px-6 max-w-4xl text-center"
        >
          <span className="section-label">Service Areas</span>
          <h2 className="text-3xl font-heading font-extrabold text-secondary mb-8">Plumbing Services in LA, OC, and IE Area</h2>
          <p className="text-gray-600 mb-6 leading-relaxed">
            If you're searching for <strong>plumbers in Los Angeles</strong> or the <strong>best plumbing service near me</strong>, Premium Pros Plumbing is your local expert. We specialize in fast, friendly service — from general repairs to smart leak detection and sewer upgrades — making sure you get the best price.
          </p>
          <div className="flex flex-wrap justify-center gap-3 my-8">
            {["Los Angeles", "Orange County", "Inland Empire", "Riverside", "Anaheim", "Santa Ana", "Irvine", "Long Beach", "San Bernardino", "Ontario"].map((city, i) => (
              <span key={i} className="inline-flex items-center gap-1.5 bg-gray-50 border border-gray-200 rounded-full px-4 py-2 text-sm font-semibold text-secondary shadow-sm">
                <MapPin className="w-3 h-3 text-primary" /> {city}
              </span>
            ))}
          </div>
          <p className="text-gray-800 font-medium">
            We are the premium plumbing pros you can trust. Call <a href="tel:+13235978330" className="text-primary font-bold">(323) 597-8330</a> for a FREE estimate! Hablamos Español!
          </p>
        </motion.div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gray-50 overflow-hidden">
        <div className="container mx-auto px-4 md:px-6 max-w-3xl">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <span className="section-label">FAQs</span>
            <h2 className="text-3xl md:text-4xl font-heading font-extrabold text-secondary mb-4">Frequently Asked Questions</h2>
          </motion.div>
          <div className="space-y-4">
            {[
              { q: "How much does general plumbing repair cost in our service areas?", a: "Depending on the repair, costs can vary. Simple repairs can be low, while larger replacements take more. But remember, we match any written estimate to give you the best price!" },
              { q: "How quickly can you resolve my plumbing issue?", a: "We offer priority and same-day service for emergencies. Most plumbing repairs and diagnostic visits are handled on the very same day." },
              { q: "Do you offer a warranty on your plumbing repairs?", a: "Yes! All our work comes with a reliable workmanship warranty to ensure peace of mind for your home." },
              { q: "Do you clean up after the job is done?", a: "Absolutely. We pride ourselves on fast, friendly, and clean service. Your home will look just as we found it, or better." }
            ].map((faq, i) => (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.1 }}
                key={i} 
                className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden"
              >
                <button 
                  onClick={() => setOpenFaqIndex(openFaqIndex === i ? null : i)}
                  className="w-full text-left p-6 flex items-center justify-between focus:outline-none"
                >
                  <h4 className="font-bold text-secondary text-lg flex items-start gap-3">
                    <div className="text-primary mt-1"><CheckCircle className="w-5 h-5"/></div>
                    {faq.q}
                  </h4>
                  <motion.div 
                    animate={{ rotate: openFaqIndex === i ? 180 : 0 }}
                    transition={{ duration: 0.3 }}
                    className="text-gray-400 ml-4 flex-shrink-0"
                  >
                    <ChevronDown className="w-5 h-5" />
                  </motion.div>
                </button>
                <AnimatePresence>
                  {openFaqIndex === i && (
                    <motion.div 
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3, ease: "easeInOut" }}
                    >
                      <div className="px-6 pb-6 pl-14 text-gray-600">
                        {faq.a}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA & Contact Form Section */}
      <section className="py-20 bg-gradient-to-br from-secondary to-secondary-dark relative overflow-hidden" id="contact">
        <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="flex flex-col lg:flex-row gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6 }}
              className="flex-1 text-center lg:text-left"
            >
              <span className="section-label-white">Free Estimate</span>
              <h2 className="text-3xl md:text-5xl font-heading font-black text-white mb-6 leading-tight">
                Get Your Free Plumbing Estimate Today
              </h2>
              <p className="text-xl text-white/80 mb-10 max-w-xl mx-auto lg:mx-0">
                Don't wait for a small problem to become a big one. Our plumbing experts serve all of LA, OC, and the Inland Empire.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
                <a href="tel:+13235978330" className="btn-call bg-white text-secondary hover:bg-gray-100 px-8 py-4 rounded-full font-bold text-lg flex items-center justify-center gap-2 w-full sm:w-auto">
                  <Phone className="w-5 h-5" /> (323) 597-8330
                </a>
              </div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="w-full max-w-md lg:w-1/2"
            >
              <div className="bg-white rounded-2xl p-6 md:p-8 shadow-2xl">
                <div className="text-center mb-6">
                  <h3 className="font-heading text-2xl font-extrabold text-secondary mb-2">Request a Call Back</h3>
                  <p className="text-gray-500 text-sm">Fill out the form below and we'll contact you shortly.</p>
                </div>
                <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                  <div>
                    <label className="flex items-center gap-2 text-sm font-bold text-gray-700 mb-1">
                      <User className="w-4 h-4 text-primary" /> Full Name *
                    </label>
                    <input type="text" placeholder="John Smith" className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-primary focus:ring-4 focus:ring-primary/10 outline-none transition-all" required />
                  </div>
                  <div>
                    <label className="flex items-center gap-2 text-sm font-bold text-gray-700 mb-1">
                      <Phone className="w-4 h-4 text-primary" /> Phone Number *
                    </label>
                    <input type="tel" placeholder="(555) 123-4567" className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-primary focus:ring-4 focus:ring-primary/10 outline-none transition-all" required />
                  </div>
                  <div>
                    <label className="flex items-center gap-2 text-sm font-bold text-gray-700 mb-1">
                      <MapPin className="w-4 h-4 text-primary" /> Zip Code
                    </label>
                    <input type="text" placeholder="90001" className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-primary focus:ring-4 focus:ring-primary/10 outline-none transition-all" />
                  </div>
                  <motion.button 
                    whileHover={{ scale: 1.02 }} 
                    whileTap={{ scale: 0.98 }} 
                    type="submit" 
                    className="w-full btn-primary py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl transition-all mt-2"
                  >
                    Submit Request
                  </motion.button>
                </form>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-secondary-dark pt-16 pb-8 border-t border-white/10">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="container mx-auto px-4 md:px-6"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
            <div>
              <a href="#" className="flex items-center gap-3 text-white mb-6">
                <img src="/1000165154-removebg-preview.png" alt="Premium Pros Plumbing Logo" className="h-12 w-auto" />
                <div className="flex flex-col leading-tight">
                  <span className="font-heading font-extrabold text-lg tracking-tight">Premium Pros Plumbing</span>
                </div>
              </a>
              <p className="text-white/60 text-sm mb-6">LA, OC, and IE Area's trusted plumbers. We match your price to give you the best deal!</p>
            </div>
            
            <div>
              <h4 className="font-heading font-bold text-white uppercase tracking-wider mb-6">Quick Links</h4>
              <ul className="space-y-3">
                <li><a href="#services" className="text-white/60 hover:text-primary transition-colors text-sm flex items-center gap-2"><ChevronRight className="w-4 h-4"/> Our Services</a></li>
                <li><a href="#why-us" className="text-white/60 hover:text-primary transition-colors text-sm flex items-center gap-2"><ChevronRight className="w-4 h-4"/> Why Choose Us</a></li>
                <li><a href="#quote" className="text-white/60 hover:text-primary transition-colors text-sm flex items-center gap-2"><ChevronRight className="w-4 h-4"/> Get Free Estimate</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-heading font-bold text-white uppercase tracking-wider mb-6">Services</h4>
              <ul className="space-y-3">
                <li><a href="#services" className="text-white/60 hover:text-primary transition-colors text-sm flex items-center gap-2"><ChevronRight className="w-4 h-4"/> Trenchless Pipe Lining</a></li>
                <li><a href="#services" className="text-white/60 hover:text-primary transition-colors text-sm flex items-center gap-2"><ChevronRight className="w-4 h-4"/> Hydro Jetting</a></li>
                <li><a href="#services" className="text-white/60 hover:text-primary transition-colors text-sm flex items-center gap-2"><ChevronRight className="w-4 h-4"/> Pipe Bursting</a></li>
                <li><a href="#services" className="text-white/60 hover:text-primary transition-colors text-sm flex items-center gap-2"><ChevronRight className="w-4 h-4"/> Camera Inspection</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-heading font-bold text-white uppercase tracking-wider mb-6">Contact Us</h4>
              <ul className="space-y-4">
                <li className="flex items-start gap-3 text-white/80 text-sm">
                  <Building className="w-5 h-5 text-primary flex-shrink-0" />
                  <span><strong>Premium Pros Plumbing</strong><br/>Serving LA, OC & IE</span>
                </li>
                <li className="flex items-start gap-3 text-white/80 text-sm">
                  <Phone className="w-5 h-5 text-primary flex-shrink-0" />
                  <span><a href="tel:+13235978330" className="font-bold text-white hover:text-primary transition-colors">(323) 597-8330</a><br/>Hablamos Español!</span>
                </li>
                <li className="flex items-start gap-3 text-white/80 text-sm">
                  <Mail className="w-5 h-5 text-primary flex-shrink-0" />
                  <a href="mailto:info@premiumprosplumbing.com" className="hover:text-primary transition-colors break-all">info@premiumprosplumbing.com</a>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-center md:text-left">
            <p className="text-white/40 text-sm">© 2026 Premium Pros Plumbing. All Rights Reserved.</p>
            <div className="flex items-center gap-4 text-sm text-white/40">
              <a href="#" className="hover:text-primary transition-colors">Privacy Policy</a>
              <span>•</span>
              <a href="#" className="hover:text-primary transition-colors">Terms of Service</a>
            </div>
          </div>
        </motion.div>
      </footer>

      {/* Sticky Mobile CTA */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 flex shadow-[0_-4px_20px_rgba(0,0,0,0.2)]">
        <a href="tel:+13235978330" className="flex-1 bg-secondary text-white font-bold py-4 flex items-center justify-center gap-2">
          <Phone className="w-5 h-5" /> Call Now
        </a>
        <a href="#quote" className="flex-1 bg-gradient-to-br from-primary to-primary-dark text-white font-bold py-4 flex items-center justify-center gap-2">
          <ClipboardList className="w-5 h-5" /> Free Estimate
        </a>
      </div>
    </div>
  );
}
